# Advocate Tasrin Zaman Rity - Professional Website

A professional website for Advocate Tasrin Zaman Rity with admin panel and OTP authentication system.

## 🌐 Live Website
[View Live Site](https://your-username.github.io/Advocate-Tasrin-Zaman-Rity-Website/)

## 🚀 Features

- **Professional Design** with Bengali & English support
- **Responsive Layout** for all devices
- **Admin Panel** with OTP authentication
- **Content Management System**
- **Email Integration** for OTP verification
- **Social Media Integration**

## 📁 File Structure
